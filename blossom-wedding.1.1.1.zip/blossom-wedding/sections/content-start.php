<?php
/**
 * Content Start
 *  
 * @package Blossom_Wedding
 */
?>

<div id="content" class="site-content">